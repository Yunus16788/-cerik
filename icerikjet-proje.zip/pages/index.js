import { useState } from 'react';

export default function Home() {
  const [giris, setInput] = useState('');
  const [cikti, setOutput] = useState('');

  const handleClick = async () => {
    const res = await fetch('/api/generate', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ istem: giris }),
    });

    const veri = await res.json();
    setOutput(veri.sonuc);
  };

  return (
    <div style={{ padding: 40 }}>
      <h1>İçerikJet</h1>
      <textarea
        value={giris}
        onChange={(e) => setInput(e.target.value)}
        rows="4"
        cols="50"
      />
      <br />
      <button onClick={handleClick}>İçerik Üret</button>
      <pre>{cikti}</pre>
    </div>
  );
}
